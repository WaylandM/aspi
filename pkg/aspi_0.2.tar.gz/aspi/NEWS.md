# aspi 0.2
* first release to CRAN
