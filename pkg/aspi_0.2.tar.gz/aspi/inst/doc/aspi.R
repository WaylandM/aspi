## ------------------------------------------------------------------------
library(aspi)
simulated_symmetrical_infection

## ---- fig.show='hold'----------------------------------------------------

plot(10:1)

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))

