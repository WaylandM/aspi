library(testthat)
library(aspi)

test_check("aspi")

